<?php

#Don't believe in the comments

#This is a comment

/**
 * Multi-comment is real
 * This need to have an end comment or everything below it will become a comment!
 */

#Echo is print
echo "<h1>This is PHP</h1>";

#Variables
$firstName = "Franc Alvenn";
$lastName = "Dela Cruz";
$age = 20;


echo "Hi, I am ".$firstName. " " .$lastName. "!";

$x = 5;
$y = 10;
$z = 20;

$sum = $x + $y * $z;

echo $sum;


?>