<h1>Functions</h1>

<?php

function editUser($value, $age){
    
}


?>