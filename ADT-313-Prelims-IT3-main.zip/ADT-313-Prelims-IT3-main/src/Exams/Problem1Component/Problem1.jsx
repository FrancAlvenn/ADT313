import React from 'react'

function Problem1() {
  return (
    <div>
        <h1>Franc Alvenn Dela Cruz</h1>
        <h3>BSIT-3A</h3>
    </div>
  )
}

export default Problem1