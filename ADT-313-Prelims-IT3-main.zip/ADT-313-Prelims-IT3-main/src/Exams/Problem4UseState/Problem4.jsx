import { useState } from "react";

export default function Problem4() {

  const [name, setName] = useState("")
  const [year_level, setYearLevel] = useState('')
  const [course, setCourse] = useState('')

  function handleNameChange(e){
    setName(e.target.value);
  }

  function handleYearLevelChange(e){
    setYearLevel(e.target.value)
  }

  function handleCourseChange(e){
    setCourse(e.target.value)
  }

  return (
    <>
      <div style={{ display: 'block' }}>
        Name: <input type='text' value={name} onChange={(e) => handleNameChange(e)} />
      </div>
      <div style={{ display: 'block' }}>
        <p>Yearlevel:</p>
        <input type='radio' id='firstYear' name='yearlevel' value='Fist Year' onClick={handleYearLevelChange}  />
          <label for='firstYear'>Fist Year</label>
        <br></br>
        <input
          type='radio'
          id='secondYear'
          name='yearlevel'
          value='Second Year'
          onClick={handleYearLevelChange}
        />
          <label for='secondYear'>Second Year</label>
        <br></br>
        <input
          type='radio'
          id='thirdYear'
          name='yearlevel'
          value='Third Year'
          onClick={handleYearLevelChange}
        />
          <label for='thirdYear'>Third Year</label>
        <br></br>
        <input
          type='radio'
          id='fourthYear'
          name='yearlevel'
          value='Fourth Year'
          onClick={handleYearLevelChange}
        />
          <label for='fourthYear'>Fourth Year</label>
        <br></br>
        <input
          type='radio'
          id='fifthYear'
          name='yearlevel'
          value='Fifth Year'
          onClick={handleYearLevelChange}
        />
          <label for='fifthYear'>Fifth Year</label>
        <br></br>
        <input type='radio' id='irregular' name='yearlevel' value='Irregular' onClick={handleYearLevelChange} />
          <label for='irregular'>Irregular</label>
        <br></br>
      </div>
      <div style={{ display: 'block' }}>
        Course:
        <select onClick={handleCourseChange}>
          <option value='BSCS'>BSCS</option>
          <option value='BSIT'>BSIT</option>
          <option value='BSCpE'>BSCpE</option>
          <option value='ACT'>ACT</option>
        </select>
      </div>

      <p>{name}</p>
      <p>{year_level}</p>
      <p>{course}</p>
    </>
  );
}
