import { useReducer, useRef, useState } from "react";



function Problem3() {

  const [inputValue1, setInputValue1] = useState("");
  const [inputValue2, setInputValue2] = useState("");
  const [inputValue3, setInputValue3] = useState("");
  const [inputValue4, setInputValue4] = useState("");
  const [inputValue5, setInputValue5] = useState("");
  const [inputValue6, setInputValue6] = useState("");
  const [inputValue7, setInputValue7] = useState("");
  const [inputValue8, setInputValue8] = useState("");
  const [inputValue9, setInputValue9] = useState("");
  const [inputValue10, setInputValue10] = useState("");

  function handleInputChange(event, type) {
    switch(type){
      case 1:
        setInputValue1(event.target.value);
        break
      case 2:
        setInputValue2(event.target.value);
        break
      case 3:
        setInputValue3(event.target.value);
        break
      case 4:
        setInputValue4(event.target.value);
        break
      case 5:
        setInputValue5(event.target.value);
        break
      case 6:
        setInputValue6(event.target.value);
        break
      case 7:
        setInputValue7(event.target.value);
        break
      case 8:
        setInputValue8(event.target.value);
        break
      case 9:
        setInputValue9(event.target.value);
        break
      case 10:
        setInputValue10(event.target.value);
        break
    }
  }

  const [isEmpty1, setIsEmpty] = useState()

  const inputRef1 = useRef(null);
  const inputRef2 = useRef(null);
  const inputRef3 = useRef(null);
  const inputRef4 = useRef(null);
  const inputRef5 = useRef(null);
  const inputRef6 = useRef(null);
  const inputRef7 = useRef(null);
  const inputRef8 = useRef(null);
  const inputRef9 = useRef(null);
  const inputRef10 = useRef(null);

  const focusInput = () => {
    if (inputValue1.trim() === "") {
      inputRef1.current.focus();
    }
    if (inputValue2.trim() === "") {
      inputRef2.current.focus();
    }
    if (inputValue3.trim() === "") {
      inputRef3.current.focus();
    }
    if (inputValue4.trim() === "") {
      inputRef4.current.focus();
    }
    if (inputValue5.trim() === "") {
      inputRef5.current.focus();
    }
    if (inputValue6.trim() === "") {
      inputRef6.current.focus();
    }
    if (inputValue7.trim() === "") {
      inputRef7.current.focus();
    }
    if (inputValue8.trim() === "") {
      inputRef8.current.focus();
    }
    if (inputValue9.trim() === "") {
      inputRef9.current.focus();
    }
    if (inputValue10.trim() === "") {
      inputRef10.current.focus();
    }
    
  };


  return (
    <>
      <div style={{ display: 'block' }}>
        Input 1: <input ref={inputRef1} type='text' value={inputValue1} onChange={(e) => handleInputChange(e, 1)} />
      </div>
      <div style={{ display: 'block' }}>
        Input 2: <input ref={inputRef2}  type='text' value={inputValue2} onChange={(e) => handleInputChange(e, 2)} />
      </div>
      <div style={{ display: 'block' }}>
        Input 3: <input ref={inputRef3}type='text' value={inputValue3} onChange={(e) => handleInputChange(e, 3)} />
      </div>
      <div style={{ display: 'block' }}>
        Input 4: <input ref={inputRef4} type='text' value={inputValue4} onChange={(e) => handleInputChange(e, 4)} />
      </div>
      <div style={{ display: 'block' }}>
        Input 5: <input ref={inputRef5} type='text' value={inputValue5} onChange={(e) => handleInputChange(e, 5)} />
      </div>
      <div style={{ display: 'block' }}>
        Input 6: <input ref={inputRef6} type='text'  value={inputValue6} onChange={(e) => handleInputChange(e, 6)}/>
      </div>
      <div style={{ display: 'block' }}>
        Input 7: <input ref={inputRef7} type='text' value={inputValue7} onChange={(e) => handleInputChange(e, 7)} />
      </div>
      <div style={{ display: 'block' }}>
        Input 8: <input ref={inputRef8} type='text' value={inputValue8} onChange={(e) => handleInputChange(e, 8)} />
      </div>
      <div style={{ display: 'block' }}>
        Input 9: <input ref={inputRef9} type='text' value={inputValue9} onChange={(e) => handleInputChange(e, 9)} />
      </div>
      <div style={{ display: 'block' }}>
        Input 10: <input ref={inputRef10} type='text '  value={inputValue10} onChange={(e) => handleInputChange(e, 10)}/>
      </div>
      <button type='button' onClick={focusInput}>I'm a button</button>
    </>
  );
}

export default Problem3;
