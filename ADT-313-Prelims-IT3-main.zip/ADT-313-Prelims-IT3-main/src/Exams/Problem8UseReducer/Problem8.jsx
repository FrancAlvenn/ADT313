import { useCallback, useEffect, useReducer, useState } from 'react';
import data from './problem8mock_data.json';
export default function Problem8() {
  const [foods, setFoods] = useState(data);
  const [selected, setSelected] = useState();

  const initialState = {data};

  const reducer = (state, action) =>{
    switch (action.type) {
      case 'create':
      case 'clear':
          setSelected(null)
          break
      case 'edit':
          setSelected(foods[action.index])
          break
      case 'delete':
        const newFoods = foods

        //delete newFoods[action.index]

        newFoods.splice(action.index, 1)

          setFoods(newFoods)
          console.log(foods)
          break
      default:
          throw new Error('Unknown action');
  }
  }

  const [state, dispatch] = useReducer(reducer, initialState);

  //console.log(selected)

  return (
    <>
      <div>
        <div style={{ display: 'block' }}>
          Food Name:{' '}
          <input
            type='text'
            value={selected && selected.food_name ? selected.food_name : ''}
          />
        </div>
        <div style={{ display: 'block' }}>
          Price:{' '}
          <input
            type='text'
            value={selected && selected.price ? selected.price : ''}
          />
        </div>
        <div style={{ display: 'block' }}>
          Expiration Date:{' '}
          <input
            type='text'
            value={
              selected && selected.expiration_date
                ? selected.expiration_date
                : ''
            }
          />
        </div>
        <div style={{ display: 'block' }}>
          Calories:{' '}
          <input
            type='text'
            value={selected && selected.calories ? selected.calories : ''}
          />
        </div>

        <button type='button'>Save</button>
        <button type='button' onClick={() => dispatch({ type: 'clear'})}>Clear</button>
      </div>
      <div className='table-container'>
        <table style={{ width: '100%' }}>
          <thead>
            <tr>
              <th>Food Name</th>
              <th>Price</th>
              <th>Expiration Date</th>
              <th>Calories</th>
            </tr>
          </thead>
          <tbody style={{ textAlign: 'center' }}>
            {foods.map((car, index) => {
              return (
                <tr>
                  <td>{index}</td>
                  <td>{car.food_name}</td>
                  <td>{car.price}</td>
                  <td>{car.expiration_date}</td>
                  <td>{car.calories}</td>
                  <td>
                    <button type='button' value={index} onClick={() => dispatch({ type: 'edit', index: index })} >Edit</button>
                    <button type='button' value={index} onClick={() => dispatch({ type: 'delete', index: index })}>Delete</button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </>
  );
}
